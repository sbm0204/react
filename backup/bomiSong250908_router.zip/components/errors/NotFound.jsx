function NotFound() {
  return(
    <>
      <h2 style={{color: 'deeppink'}}>Not Found</h2>
    </>
  )
}

export default NotFound;